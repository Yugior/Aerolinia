#ifndef TRABAJO_H
#define TRABAJO_H

#include <string>
#include "premier.h"

class Trabajo {
private:
    int numAsientos;
    std::string tipoServicio; // Puede ser "bebida" o "entretenimiento"
    Premier premier; // Agregar una instancia de la subclase Premier

public:
    // Constructor
    Trabajo();

    // Getter y Setter para Número de asientos
    int getNumAsientos() const;
    void setNumAsientos(int numAsientos);

    // Getter y Setter para Tipo de servicio
    std::string getTipoServicio() const;
    void setTipoServicio(const std::string& tipoServicio);

    // Getter y Setter para Premier
    Premier getPremier() const;
    void setPremier(const Premier& premier);

    // Método para pedir información de asientos y tipo de servicio
    void pedirInformacion();
};

#endif // TRABAJO_H
