#include "vuelo.h"
#include <iostream>

// Constructor
Vuelo::Vuelo() {}

// Getter y Setter para Piloto
std::string Vuelo::getPiloto() const {
    return piloto;
}

void Vuelo::setPiloto(const std::string& piloto) {
    this->piloto = piloto;
}

// Getter y Setter para Copiloto
std::string Vuelo::getCopiloto() const {
    return copiloto;
}

void Vuelo::setCopiloto(const std::string& copiloto) {
    this->copiloto = copiloto;
}

// Getter y Setter para Fecha de salida
std::string Vuelo::getFechaSalida() const {
    return fechaSalida;
}

void Vuelo::setFechaSalida(const std::string& fechaSalida) {
    this->fechaSalida = fechaSalida;
}

// Getter y Setter para Avión
std::string Vuelo::getAvion() const {
    return avion;
}

void Vuelo::setAvion(const std::string& avion) {
    this->avion = avion;
}

// Método que selecciona el vuelo
void Vuelo::seleccionarVuelo() {
    std::cout << "Ingrese el nombre del piloto: ";
    std::getline(std::cin, piloto);

    std::cout << "Ingrese el nombre del copiloto: ";
    std::getline(std::cin, copiloto);

    std::cout << "Ingrese la fecha de salida: ";
    std::getline(std::cin, fechaSalida);

    std::cout << "Ingrese el modelo del avión: ";
    std::getline(std::cin, avion);
}
